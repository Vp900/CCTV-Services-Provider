function updateTime(){
    var date = new Date();
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var seconds = date.getSeconds();
    hours = updateTimeFormat(hours);
    minutes = updateTimeFormat(minutes);
    seconds = updateTimeFormat(seconds);
   document.getElementById("clock").textContent = hours + ":" + minutes + ":" + seconds;
   setTimeout(updateTime,1000);
   }
   function updateTimeFormat(time)
   {
   if (time<10)
   {
   return "0" + time;
   }
   else
   {
   return time;
   }
   }
   updateTime();